# miniburp — mobile-friendly mitmproxy GUI

A tiny Burp-style GUI built on top of mitmproxy, made to run entirely on
Android + Termux. No laptop needed.

Features:
- **Target tree** — traffic grouped by host, tap into any request/response
- **Repeater** — edit and resend any request, view the new response, copy as curl
- **Match/Replace** — rules that auto-edit matching traffic on the fly
- **Comparer** — pick two flows, see a line-by-line diff

## 1. Install (Termux)

```bash
pkg update && pkg upgrade
pkg install python rust binutils python-cryptography python-bcrypt libffi openssl
export ANDROID_API_LEVEL=$(getprop ro.build.version.sdk)
pip install mitmproxy aiohttp
```

If `cryptography` still fails to build, hardcode your API level instead of
using `getprop` (Settings → About Phone → Android version → look up the
matching API number), e.g. `export ANDROID_API_LEVEL=33`.

## 2. Get the project files

Put `addon.py` and the `static/` folder (containing `index.html`) in the
same directory, e.g.:

```
~/miniburp/
├── addon.py
└── static/
    └── index.html
```

## 3. Run it

```bash
cd ~/miniburp
mitmdump -s addon.py
```

You should see:
```
HTTP(S) proxy listening at *:8080.
miniburp GUI running at http://127.0.0.1:8082
```

## 4. Set your phone's proxy

Settings → Wi-Fi → long-press your network → Modify → Proxy: Manual
- Host: `127.0.0.1`
- Port: `8080`

## 5. Install the mitmproxy CA cert (needed for HTTPS)

With the proxy active, open your browser and visit `mitm.it`, download the
Android cert, then: Settings → Security → Encryption & credentials →
Install a certificate → CA certificate.

## 6. Open the GUI

In your phone's browser, go to:
```
http://127.0.0.1:8082
```

Browse some traffic, then hit **Refresh** on the Target tab to see it show
up, grouped by domain.

## Notes

- The GUI auto-refreshes the flow list every 4 seconds while the Target
  tab is open.
- Repeater sends requests **independently** of the proxy pipeline (via
  aiohttp directly) — it won't show up back in your own flow list.
- Match/Replace rules apply live to *all* traffic passing through the
  proxy while mitmdump is running, not just what you're viewing.
- Keep Termux alive in the background with `termux-wake-lock` if you want
  long capture sessions without Android killing the process.
- To stop: `Ctrl+C` in the mitmdump session, then remove the manual proxy
  in Wi-Fi settings (otherwise every app on the phone loses internet).
