"""
miniburp addon.py
Run with:  mitmdump -s addon.py
Web UI served at:      http://127.0.0.1:8082
Proxy listens at:      127.0.0.1:8080  (default mitmproxy port)

This addon turns mitmproxy into a headless engine and exposes everything
your own frontend needs over a small REST API on a second port.
"""

import asyncio
import json
import time
import uuid
from pathlib import Path

from aiohttp import web, ClientSession, ClientTimeout
from mitmproxy import http, ctx

STATIC_DIR = Path(__file__).parent / "static"

# ---------------------------------------------------------------------------
# In-memory state
# ---------------------------------------------------------------------------

flows_store = {}        # flow_id -> dict (serialized flow, request+response)
intercept_enabled = False
intercept_filter = ""   # substring match against host, empty = match all
pending_intercepts = {}  # flow_id -> mitmproxy Flow object (paused, waiting for user)
match_replace_rules = [] # list of rule dicts


def serialize_flow(flow: http.HTTPFlow) -> dict:
    req = flow.request
    resp = flow.response
    return {
        "id": flow.id,
        "host": req.pretty_host,
        "method": req.method,
        "path": req.path,
        "url": req.url,
        "http_version": req.http_version,
        "request_headers": list(req.headers.items(multi=True)),
        "request_body": req.get_text(strict=False) if req.content else "",
        "status_code": resp.status_code if resp else None,
        "response_headers": list(resp.headers.items(multi=True)) if resp else [],
        "response_body": (resp.get_text(strict=False)[:20000] if resp and resp.content else ""),
        "timestamp": req.timestamp_start,
        "intercepted": flow.id in pending_intercepts,
    }


def apply_match_replace(flow: http.HTTPFlow, stage: str):
    """stage is 'request' or 'response'. Applies every enabled rule in order."""
    for rule in match_replace_rules:
        if not rule.get("enabled", True):
            continue
        if rule.get("stage") != stage:
            continue
        field = rule["field"]          # "header" | "body" | "url"
        match_val = rule["match"]
        replace_val = rule["replace"]
        header_name = rule.get("header_name", "")

        target = flow.request if stage == "request" else flow.response
        if target is None:
            continue

        try:
            if field == "header":
                if header_name in target.headers:
                    if match_val in target.headers[header_name]:
                        target.headers[header_name] = target.headers[header_name].replace(
                            match_val, replace_val
                        )
            elif field == "body":
                text = target.get_text(strict=False)
                if match_val in text:
                    target.set_text(text.replace(match_val, replace_val))
            elif field == "url" and stage == "request":
                if match_val in target.url:
                    target.url = target.url.replace(match_val, replace_val)
        except Exception as e:
            ctx.log.warn(f"match/replace rule failed: {e}")


# ---------------------------------------------------------------------------
# mitmproxy hooks
# ---------------------------------------------------------------------------

def request(flow: http.HTTPFlow):
    apply_match_replace(flow, "request")

    if intercept_enabled:
        host = flow.request.pretty_host
        if intercept_filter == "" or intercept_filter in host:
            pending_intercepts[flow.id] = flow
            flow.intercept()  # pauses the flow until flow.resume() is called

    flows_store[flow.id] = serialize_flow(flow)


def response(flow: http.HTTPFlow):
    apply_match_replace(flow, "response")
    flows_store[flow.id] = serialize_flow(flow)


# ---------------------------------------------------------------------------
# REST API handlers
# ---------------------------------------------------------------------------

async def api_flows(request_):
    host_filter = request_.query.get("host", "")
    method_filter = request_.query.get("method", "")
    result = list(flows_store.values())
    if host_filter:
        result = [f for f in result if host_filter.lower() in f["host"].lower()]
    if method_filter:
        result = [f for f in result if f["method"] == method_filter.upper()]
    result.sort(key=lambda f: f["timestamp"], reverse=True)
    return web.json_response(result)


async def api_flow_detail(request_):
    flow_id = request_.match_info["flow_id"]
    flow = flows_store.get(flow_id)
    if not flow:
        return web.json_response({"error": "not found"}, status=404)
    return web.json_response(flow)


async def api_target_tree(request_):
    """Groups flows by host -> path, for the Target tree view."""
    tree = {}
    for f in flows_store.values():
        host = f["host"]
        path = f["path"].split("?")[0]
        tree.setdefault(host, {})
        tree[host].setdefault(path, [])
        tree[host][path].append({"id": f["id"], "method": f["method"], "status": f["status_code"]})
    return web.json_response(tree)


async def api_intercept_toggle(request_):
    global intercept_enabled, intercept_filter
    data = await request_.json()
    intercept_enabled = bool(data.get("enabled", False))
    intercept_filter = data.get("filter", "")
    return web.json_response({"enabled": intercept_enabled, "filter": intercept_filter})


async def api_intercept_queue(request_):
    queue = [serialize_flow(f) for f in pending_intercepts.values()]
    return web.json_response(queue)


async def api_intercept_forward(request_):
    """Body: {method, url, headers: [[k,v],...], body: str}  — applies edits then resumes."""
    flow_id = request_.match_info["flow_id"]
    flow = pending_intercepts.get(flow_id)
    if not flow:
        return web.json_response({"error": "not found"}, status=404)

    data = await request_.json()
    if data:
        flow.request.method = data.get("method", flow.request.method)
        flow.request.url = data.get("url", flow.request.url)
        if "headers" in data:
            flow.request.headers.clear()
            for k, v in data["headers"]:
                flow.request.headers[k] = v
        if "body" in data:
            flow.request.set_text(data["body"])

    del pending_intercepts[flow_id]
    flow.resume()
    return web.json_response({"status": "forwarded"})


async def api_intercept_drop(request_):
    flow_id = request_.match_info["flow_id"]
    flow = pending_intercepts.pop(flow_id, None)
    if flow:
        flow.kill()
    return web.json_response({"status": "dropped"})


async def api_repeater_send(request_):
    """Fires an independent HTTP request (not through the mitmproxy pipeline)."""
    data = await request_.json()
    method = data.get("method", "GET")
    url = data.get("url")
    headers = dict(data.get("headers", []))
    body = data.get("body", "")

    try:
        timeout = ClientTimeout(total=15)
        async with ClientSession(timeout=timeout) as session:
            async with session.request(method, url, headers=headers, data=body.encode() if body else None,
                                        ssl=False) as resp:
                resp_body = await resp.text()
                return web.json_response({
                    "status_code": resp.status,
                    "headers": list(resp.headers.items()),
                    "body": resp_body[:20000],
                })
    except Exception as e:
        return web.json_response({"error": str(e)}, status=502)


async def api_rules_get(request_):
    return web.json_response(match_replace_rules)


async def api_rules_post(request_):
    data = await request_.json()
    data["id"] = str(uuid.uuid4())
    data.setdefault("enabled", True)
    match_replace_rules.append(data)
    return web.json_response(data)


async def api_rules_delete(request_):
    rule_id = request_.match_info["rule_id"]
    global match_replace_rules
    match_replace_rules = [r for r in match_replace_rules if r["id"] != rule_id]
    return web.json_response({"status": "deleted"})


async def api_rules_toggle(request_):
    rule_id = request_.match_info["rule_id"]
    data = await request_.json()
    for r in match_replace_rules:
        if r["id"] == rule_id:
            r["enabled"] = data.get("enabled", True)
    return web.json_response({"status": "ok"})


async def api_clear(request_):
    flows_store.clear()
    return web.json_response({"status": "cleared"})


# ---------------------------------------------------------------------------
# aiohttp app setup + static file serving
# ---------------------------------------------------------------------------

def build_app():
    app = web.Application()
    app.router.add_get("/api/flows", api_flows)
    app.router.add_get("/api/flows/{flow_id}", api_flow_detail)
    app.router.add_get("/api/target-tree", api_target_tree)
    app.router.add_post("/api/intercept/toggle", api_intercept_toggle)
    app.router.add_get("/api/intercept/queue", api_intercept_queue)
    app.router.add_post("/api/intercept/{flow_id}/forward", api_intercept_forward)
    app.router.add_post("/api/intercept/{flow_id}/drop", api_intercept_drop)
    app.router.add_post("/api/repeater/send", api_repeater_send)
    app.router.add_get("/api/rules", api_rules_get)
    app.router.add_post("/api/rules", api_rules_post)
    app.router.add_delete("/api/rules/{rule_id}", api_rules_delete)
    app.router.add_post("/api/rules/{rule_id}/toggle", api_rules_toggle)
    app.router.add_post("/api/clear", api_clear)
    app.router.add_static("/", STATIC_DIR, show_index=True)
    return app


class WebServer:
    async def running(self):
        app = build_app()
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", 8082)
        await site.start()
        ctx.log.info("miniburp GUI running at http://127.0.0.1:8082")


addons = [WebServer()]
